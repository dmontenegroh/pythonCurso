# print('This isn\'t a number')
# print('Este signo \\ es una barra invertida')
# print('L\ínea')
# print('A\tB\tC\nD\tE\tF\nG\tH\tI\n')
# print("Tu nombre es: " + input("Dime tu nombre: ") + " " + input("Dime tu apellido: "))

# Práctica Print 1

print("Me encanta estudiar Python")

# Práctica Print 2

print('Estudiar con "Python Total" es super divertido')

# Práctica Print 3

print(5+550)

# Práctica String 1

print("Línea 1\nLínea 2\nLínea 3")

# Práctica String 2

print("A\tB\tC\nD\tE\tF\nG\tH\tI")

# Práctica String 3

print("Barra Normal: /\nBarra Invertida: \\")

# Práctica Input 1

print(input("¿Qué estás estudiando?"))

# Práctica Input 2

print(input("¿En qué país vives?"))

# Práctica Input 3

print(input("Escribe tu nombre:")+" "+input("Escribe tu apellido:"))

# ---------------------------------------------------------------
