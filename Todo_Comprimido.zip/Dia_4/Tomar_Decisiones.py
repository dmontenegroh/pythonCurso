# x = True
# x = 5 == 2

# if x:
#     print('Es correcto')
# else:
#     print('No es correcto')

# mascota = 'conejo'

# if (mascota == 'gato'):
#     print('Tienes un gato')
# elif (mascota == 'perro'):
#     print('Tienes un perro')
# elif (mascota == 'pez'):
#     print('Tienes un pez')
# else:
#     print('No sé qué animal tienes')

edad = 35
calificacion = 4

if edad < 18:
    print('Eres menor de edad')
    if (calificacion > 7):
        print('Aprobado')
    else:
        print('No aprobado')
else:
    print('Eres adulto')
