# mi_variable = 'hola mundo'
mi_bool = 'blanco' == 'negro'
mi_bool = 'blanco' == 'Blanco'
mi_bool = 'blanco' == 'Blanco'.lower()
mi_bool = '100' == 100
mi_bool = 100.0 == 100
mi_bool = 5 >= 6
print (mi_bool)