# IMPORTAR METODOS
# from random import randint
from random import *  # IMPORTAMOS TODOLO QUE CONTIENE LA LIBRERIA RANDOM

# aleatorio = randint(1, 50)
# print(aleatorio)

# aleatorio = round(uniform(1,5),1)
# print(aleatorio)

# aleatorio = random()  # EJECUTA CON NUMERO RANDOM ENTRE 0 y 1
# print(aleatorio)

# colores = ['azul', 'rojo', 'verde', 'amarillo']
# aleatorio = choice(colores)
# print(aleatorio)

# numeros = list(range(5,50,5))

# shuffle(numeros)

# print(numeros)

# Implementa la función randint() de la librería random que te permita obtener un número entero del 1 al 10, y almacena dicho valor en una variable llamada aleatorio

# aleatorio = randint(1,10)
# print(aleatorio)


# Práctica Random 2
# Implementa la función random() de la librería random que te permita obtener un número decimal entre 0 y 1, y almacena dicho valor en una variable llamada aleatorio


# Práctica Random 3
# Utiliza el método choice() de la librería random para obtener un elemento al azar de la lista de nombres a continuación, y almacena el nombre escogido en una variable llamada sorteo.

nombres = ["Carlos", "Julia", "Nicole", "Laura", "Mailen"]

sorteo = choice(nombres)
print(sorteo)