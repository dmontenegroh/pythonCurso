mi_bool = 4 < 5 < 6
mi_bool = 4 < 5 and 5 > 6
mi_bool = 4 < 5 and 5 == 2+3
mi_bool = (55 == 55) and ('perro' == 'perro')
mi_bool = 10 == 10 or 3 == 3
mi_bool = 1 == 10 or 3 == 3
mi_bool = 1 == 10 or 3 == 30

texto = "esta frase es breve"
mi_bool = ('frase' in texto) and ('python' in texto)
mi_bool = ('frase' in texto) or ('python' in texto)

mi_bool = not ('a' != 'a')
mi_bool = not ('a' == 'a')


print(mi_bool)


