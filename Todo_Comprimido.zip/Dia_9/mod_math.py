import math

# resultado = math.log(100, 5)
# resultado = math.tan(2565)
resultado = math.cos(2565)
print(resultado)
