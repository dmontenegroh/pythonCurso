# import datetime
from datetime import datetime
# mi_hora = datetime.time(17,35,50,1500)
# mi_dia = datetime.date(2025, 10, 17)
# print(mi_hora)
# print(mi_dia)

mi_fecha = datetime(2023, 8, 23, 16, 5, 6, 5000)
print(mi_fecha)