# archivo = open('Material_PDF/DIA_6/Prueba.txt', 'w')
archivo = open('Material_PDF/DIA_6/Prueba.txt', 'a')
# archivo.write('soy el nuevo texto\n')
# archivo.write('hola\n')

# archivo.writelines(['hola', 'mundo', 'aqui', 'estoy'])

# lista = ['hola', 'mundo', 'aqui', 'estoy']
# for p in lista:
#     archivo.writelines(p + '\n')



archivo.close()
