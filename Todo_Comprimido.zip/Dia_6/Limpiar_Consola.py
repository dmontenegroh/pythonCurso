from os import system

nombre = input('Dime tu nombre: ')
edad = input('Dime tu edad: ')

system('cls')

print(f"Tu nombre es {nombre} y tienes {edad} años")

