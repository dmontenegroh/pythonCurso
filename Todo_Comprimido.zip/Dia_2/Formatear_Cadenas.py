# FORMA 1
# x = 10
# y = 5

# print("Mis numeros son: " + str(x) + " y " + str(y))
# print("Mis numeros son {} y {}".format(x, y))
# print("La suma de {} y {} es igual a {}".format(x, y, y+x))


# FORMA 2

color = "morado"
matricula = 363442

print(f"El Auto es {color} y su matricula es {matricula}")

nombre_asociado = "Jesse Pinkman"
numero_asociado = 399058

print(f"Estimado/a {nombre_asociado}, su número e asociado es: {numero_asociado}")