#string (str) "hola", "%$&", "", "123"
# intenger (int) 150, 1, 144, -15, 0
# floating (float) 1.24, 35.0, 25.0, -91.5
# listas (list) ["sal", 1, -3, 4.5, "marte", 0]
# diccionarios (dic) {'color': 'rojo', 'arte': 'cine'} 
# tuples (tuple) ('lun', 'mar', 'mie', 'jue', 'vie')
# sets (set) {'a', 'b', 'c', 'd', 'e'}
# booleanos (bool) True, False