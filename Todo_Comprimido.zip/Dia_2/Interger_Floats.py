# mi_numero = 1 + 3
# mi_numero2 = 5 + 5.8
# mi_numero2 = mi_numero2 + mi_numero2 
# print(mi_numero2)

# print(type(mi_numero2))

# edad = input('Dime tu edad: ')
# print("Tu edad es: " + edad)

# nueva_edad = 1 + edad

# print("Vas a cumplir " + nueva_edad)