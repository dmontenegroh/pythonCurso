x = 6
y = 2
z = 7


print(f"{x} más {y} es igual a {x+y}")
print(f"{x} menos {y} es igual a {x-y}")
print(f"{x} por {y} es igual a {x*y}")
print(f"{x} dividido {y} es igual a {x/y}")

# Division al piso (eliminar el valor dps de la coma)
print(f"{z} dividido al piso de {y} es igual a {z//y}")
# Modulo (sobrando de las diviciones)
print(f"{z} modulo de {y} es igual a {z%y}")
# Potencia
print(f"{x} elevado a la {y} es igual a {x**y}")
print(f"{x} elevado a la {3} es igual a {x**3}")
# Raiz cuadrada
print(f"La raiz cuadrada de {x} es {x**0.5}")
