# nombre = "Diego"
# print(nombre)

# nombre = "Laura"
# print(nombre)

# edad = 30
# edad2 = 15
# print(edad + edad2)

# nombre = input("dime tu nombre ")
# print("Tu nombre es " + nombre)

# nombre = "Hola "
# nombre2 = "Python"
# frase = nombre + nombre2
# print(frase)

# ---------------------------
#Reglas de nombrar variables
# 1) Legible
# 2) unidad
# 3) hispanismos
# 4) numeros
# 5) signos
# 6) palabras clave
