# print(round(90/7))

# resultado = 90/7
# redondeado = round(resultado)

# print(redondeado);


valor = 95.666666666666666
valor_redondeado = round(valor);
print(valor_redondeado);
print(type(valor_redondeado))