# var1 = True
# var2 = False

# print(type(var1))

# numero = 5 > 2+5
# numero = 5 == 2+5
# numero = 5 >= 2+3
# numero = 5 != 2+3

# numero = bool(5>6)
# numero = bool(5<6)

# lista = [1,2,3,4]
# control = 5 in lista
# print(control)

