# mi_lista = ['a', 'b', 'c']
# otra_lista = ['hola', 55, 6.4]
# print(type(mi_lista))
# print(type(otra_lista))

# resultado = len(mi_lista)
# resultado = mi_lista[0]
# resultado = mi_lista[0:]
# mi_lista2 = ['d', 'e', 'f']

# mi_lista3 = mi_lista+mi_lista2
# print(mi_lista3)

# mi_lista3[0] = 'alfa'
# mi_lista3.append('g') # agregar elemento
# mi_lista3.pop() # remover elemento (si no se le pone parametro eliminará el ultimo)

# eliminado = mi_lista3.pop(0)

# print(mi_lista3)
# print(eliminado)

lista = ['g', 'o', 'b', 'm', 'c']
lista.sort() # ordena alfabeticamente y no se puede asignar a otra variable porque no devuelve nada
lista.reverse() # ordena de manera inversa y no se puede asignar a otra variable porque no devuelve nada
print(lista)