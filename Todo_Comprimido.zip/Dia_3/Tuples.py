# mi_tuple = (1, 2, (10, 20), 4)
# # mi_tuple = (5,5.6,'FFF')

# print(mi_tuple[2][0])


t = (1,2,3,1)

# x,y,z = t

print(t.index(2))