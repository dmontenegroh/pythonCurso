texto = "Este es el texto de Diego"

# resultado = texto
# resultado = texto.upper()  # metodo para transformar en MAYUSCULAS
# resultado = texto[2].upper()  # tambien funciona solo con indices
# resultado = texto.lower()  # metodo para transformar en minusculas
# resultado = texto.split() # separa elementos y los devuelve como listas
# resultado = texto.split("t") # utiliza el parametro ingresado como separador

# print(resultado)

# a = "Aprender"
# b = "Python"
# c = "es"
# d = "genial"
# # e = " ".join([a, b, c, d]) 
# e = "-".join([a, b, c, d]) 
# print(e)

texto = "Este es el texto de Diego"
# resultado = texto.find("s")
# resultado = texto.replace("Diego", "todos")
resultado = texto.replace("e", "x")
print(resultado)