# da error porque los valores son inmutables
# nombre = "Carina"
# nombre[0] = "K"
# print(nombre)

# n1 = "Kari"
# n2 = "na"
# print(n1 + n2)
# print(n1 * 10)

poema = """Mil pequeños peces blancos 
como si hirviera 
el color del agua"""
# print(poema)
# print("agua" in poema)
# print("sol" in poema)
# print("sol" not in poema)
print(len(poema))

print("Repeticion" * 15)