mi_texto = "Esta es una prueba"
# resultado = mi_texto.index("a", 5, 10)
resultado = mi_texto.rindex("a")
print(resultado)
