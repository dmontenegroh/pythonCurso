""" FUNCION PARA SUMAR DOS NUMEROS"""


def sumar(numero1, numero2):
    # Tambien tiene que haber comentarios dentro de las funciones...
    """"
    Nos va a retornar el resultado


    Args:
    numero1 (int): primer numero a sumar
    numero2 (int): segundo numero a sumar

    return: 

    int: suma de numero1 + numero2
    """


    return numero1+numero2


SUMA = sumar(5, 7)
print(SUMA)
