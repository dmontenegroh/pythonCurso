def suma(n1, n2):
    print(n1 + n2)


def resta(n1, n2):
    print(n1 - n2)
