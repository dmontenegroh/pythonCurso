from Paquete_Diego import suma_resta
from Paquete_Diego.Subpaquete import saludo

suma_resta.resta(15,2)
suma_resta.suma(35,2)
saludo.hola()