from ModuloOcupado import saludar

saludar()