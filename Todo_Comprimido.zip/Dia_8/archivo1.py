"""
ESTE ES UN MODULO QUE IMPRIME ALGO
"""


def una_funcion():
    numero1 = 500
    print(numero1)


una_funcion()
