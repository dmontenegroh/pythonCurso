class Pajaro: 
    pass


mi_pajaro = Pajaro()
otro_pajaro = Pajaro()


print(mi_pajaro)
print(otro_pajaro)
# print(type(mi_pajaro))
# print(type(otro_pajaro))